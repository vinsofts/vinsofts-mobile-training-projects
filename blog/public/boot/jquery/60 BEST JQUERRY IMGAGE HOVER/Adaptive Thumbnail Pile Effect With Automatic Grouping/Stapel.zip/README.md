
Stapel
=========

An experimental jQuery plugin that will group thumbnails by a shared data-attribute into a pile. When clicking on the pile, the thumbnails that belong to that pile will be spread into a grid using CSS transitions.

[article on Codrops](http://tympanus.net/codrops/?p=12205)

[demo](http://tympanus.net/Development/Stapel/)

Licensed under the MIT License