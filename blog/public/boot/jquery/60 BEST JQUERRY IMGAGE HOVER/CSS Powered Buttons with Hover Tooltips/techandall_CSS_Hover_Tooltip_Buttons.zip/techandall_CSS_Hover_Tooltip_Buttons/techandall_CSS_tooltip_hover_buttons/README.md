Tooltipster
===========

A jQuery tooltip plugin by Caleb Jacob. For documentation and all that jazz,
visit: http://calebjacob.com/tooltipster
