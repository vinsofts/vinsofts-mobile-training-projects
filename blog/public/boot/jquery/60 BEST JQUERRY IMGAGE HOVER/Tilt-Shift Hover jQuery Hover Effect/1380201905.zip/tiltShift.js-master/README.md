tiltShift.js
===========

Introduction
----------------

A jQuery plugin that uses the CSS3 image filters to replicate the tilt-shift effect. This is a proof of concept and currently only works in Chrome.

Demo and install?
----------------

See here: [http://www.noeltock.com/tilt-shift-css3-jquery-plugin/](http://www.noeltock.com/tilt-shift-css3-jquery-plugin/)

License
----------------

Released under GNU GPL ( [gnu.org](http://www.gnu.org/licenses/) )